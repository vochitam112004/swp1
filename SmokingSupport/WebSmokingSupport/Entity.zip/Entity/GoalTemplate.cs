﻿using System;
using System.Collections.Generic;

namespace WebSmokingSupport.Entity;

public partial class GoalTemplate
{
    public int TemplateId { get; set; }

    public string? Description { get; set; }
}
