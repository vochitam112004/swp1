﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebSmokingSupport.Entity;

public partial class PasswordRerestToken
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public int UserId { get; set; }
    [Required]
    [StringLength(10)]
    public string OtpCode { get; set; } = null!;

    public DateTime ExpirationTime { get; set; }

    public bool IsUsed  { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [ForeignKey("UserId")]
    public virtual User User { get; set; } = null!;
}
